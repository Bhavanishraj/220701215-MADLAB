package com.example.bookdetails

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.io.FileWriter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val reg: EditText =findViewById(R.id.ettext1)
        val name: EditText =findViewById(R.id.ettext2)
        val cgpa: EditText =findViewById(R.id.ettext3)
        val price: EditText =findViewById(R.id.ettext4)
        val save: Button =findViewById(R.id.btsave)
        val load: Button =findViewById(R.id.btload)
        save.setOnClickListener {
            val reg1=reg.text.toString();
            val name1=name.text.toString();
            val cgpa1=cgpa.text.toString();
            val price1=price.text.toString();
            val file= File(getExternalFilesDir(null),"student.txt")
            val writer= FileWriter(file)
            writer.write("$reg1\n$name1\n$cgpa1\n$price1")
            writer.close()
            reg.text.clear()
            name.text.clear()
            cgpa.text.clear()
            price.text.clear()

            Toast.makeText(this,"Saved Successfully...!", Toast.LENGTH_LONG).show()

        }

        load.setOnClickListener{
            val file= File(getExternalFilesDir(null),"student.txt")
            val reader= BufferedReader(FileReader(file))
            val reg2= reader.readLine()
            val name2= reader.readLine()
            val cgpa2= reader.readLine()
            val price2=reader.readLine()
            reg.setText(reg2)
            name.setText(name2)
            cgpa.setText(cgpa2)
            price.setText(price2)
            reader.close()
            Toast.makeText(this,"Loaded Successfully...!", Toast.LENGTH_LONG).show()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}